Setup
- To view the website locally and have the links work properly simply have the files "CSS", "HTML", "IMAGE" and "index.html" contained in a folder name "website".